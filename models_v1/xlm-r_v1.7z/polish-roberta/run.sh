CUDA_VISIBLE_DEVICES=0 python3 run_tasks.py --arch roberta_base --model_dir xlmr.base --train_epochs 2 --tasks AggressionS1 --fp16 True --max_sentences 16 --update_freq 2 > aggression_s1n.log 2>&1 &
CUDA_VISIBLE_DEVICES=1 python3 run_tasks.py --arch roberta_base --model_dir xlmr.base --train-epochs 2 --tasks AggressionS2 --fp16 True --max-sentences 8 --update-freq 1 > aggression_s2n.log 2>&1  &
CUDA_VISIBLE_DEVICES=2 python3 run_tasks.py --arch roberta_base --model_dir xlmr.base --train-epochs 2 --tasks AggressionS3 --fp16 True --max-sentences 8 --update-freq 1 > aggression_s3n.log 2>&1  
#CUDA_VISIBLE_DEVICES=0 python3 run_tasks.py --arch roberta_base --model_dir xlmr.base --train-epochs 2 --tasks AggressionS3 --fp16 True --max-sentences 8 --update-freq 1
